import { prnt } from "./dep2.js";

function dep1() {
    
  return prnt();
}

export { dep1 };
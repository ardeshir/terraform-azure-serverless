function prnt () {
  return '...dependencies loaded!';
}

export { prnt };